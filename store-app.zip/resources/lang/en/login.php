<?php
return [
    'english' => 'English',
    'vietnam' => 'Vietnam',
    
    'signin' => 'Sign In',
    'username' => 'Username',
    'enterusername' => 'Enter your username...',
    'password' => 'Password',
    'enterpassword' => 'Enter your password...',
    'rememberme' => 'Remember me',
    'login' => 'Log In',
    'forgot' => 'Forgot Password',
];
?>