<?php
return [
    'ite' => 'Item',
    'war' => 'Warehouse',
    'she' => 'Shelf',
    'cat' => 'Category',
    'eim' => 'Export/Import',
    'tra' => 'Transfer',
    'inv' => 'Inventory',
    'acc' => 'Account',
    'uni' => 'Unit',
    'sup' => 'Supplier',
    'sys' => 'System',
    'sta' => 'Statistic',
    'log' => 'Logs',
];
