<?php
return [
    'english' => 'English',
    'vietnam' => 'Vietnam',

    // Account
    'welcome' => 'Welcome',
    'logout' => 'Logout',
    'myaccount' => 'My account',

    //Notify
    'clear' => 'Clear All',
    'notify' => 'Notification',
    'view' => 'View All'
];
?>
