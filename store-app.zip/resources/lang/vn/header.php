<?php
return [
    'english' => 'Tiếng Anh',
    'vietnam' => 'Tiếng Việt',

    // Account
    'welcome' => 'Xin chào',
    'logout' => 'Đăng xuất',
    'myaccount' => 'Tài khoản',

    // Notify
    'clear' => 'Xóa tất cả',
    'notify' => 'Thông báo',
    'view' => 'Xem tất cả',
];
?>
