<?php
return [
    'ite' => 'Vật tư',
    'war' => 'Kho vật tư',
    'she' => 'Giá/kệ',
    'cat' => 'Loại vật tư',
    'eim' => 'Nhập/Xuất',
    'tra' => 'Điều chuyển',
    'inv' => 'Tồn kho',
    'acc' => 'Tài khoản',
    'uni' => 'Đơn vị tính',
    'sup' => 'Nhà cung cấp',
    'sys' => 'Hệ thống',
    'sta' => 'Thống kê',
    'log' => 'Logs',
];
?>