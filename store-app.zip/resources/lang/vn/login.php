<?php
return [
    'english' => 'Tiếng Anh',
    'vietnam' => 'Tiếng Việt',
    
    'signin' => 'Đăng nhập',
    'username' => 'Tên đăng nhập',
    'enterusername' => 'Điền tên đăng nhập...',
    'password' => 'Mật khẩu',
    'enterpassword' => 'Điền mật khẩu...',
    'rememberme' => 'Nhớ tôi',
    'login' => 'Đăng nhập',
    'forgot' => 'Quên mật khẩu',
];
?>