

<?php $__env->startSection('title'); ?>
    Xác nhận điều chỉnh
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <link href="<?php echo e(asset('assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/css/app.min.css')); ?>" rel="stylesheet" type="text/css" id="light-style">
    <link href="<?php echo e(asset('assets/css/app-dark.min.css')); ?>" rel="stylesheet" type="text/css" id="dark-style">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <!-- start page title -->
        <?php
            $route = preg_replace('/(admin)|\d/i', '', str_replace('/', '', Request::getPathInfo()));
        ?>
        <?php echo e(Breadcrumbs::render($route, $inventory[0]->id)); ?>

        <!-- end page title -->
        <?php if(session()->has('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                <?php echo e(session()->get('success')); ?>

            </div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    <?php echo e($error); ?>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col">
                                <div class="text-sm-start">
                                    <a href="<?php echo e(route('inventory.index')); ?>" class="btn btn-primary mb-2 me-1"><i
                                            class="mdi mdi-backburger"></i> Back</a>
                                </div>
                            </div>
                            <div class="col">
                                <div class="text-sm-end">
                                    <form action="<?php echo e(route('inventory.update', $inventory[0]->id)); ?>" method="post">
                                        <?php echo csrf_field(); ?>
                                        <?php echo method_field('PUT'); ?>
                                        <?php if($inventory[0]->inventory_status == 0): ?>
                                            <button class="btn btn-success mb-2 me-1" type="submit">Duyệt</button>
                                        <?php else: ?>
                                            <button class="btn btn-success mb-2 me-1" disabled type="submit">Đã
                                                duyệt</button>
                                        <?php endif; ?>
                                    </form>
                                </div>
                            </div>
                        </div>

                        <br>
                        <h5 class="card-title">Thông tin</h5>
                        <form action="" class="px-5">
                            <div class="mb-3">
                                <label for="user_name" class="form-label">Người tạo:</label>
                                <input type="text" id="user_name" class="form-control" readonly
                                    value="<?php echo e($inventory[0]->name); ?>">
                            </div>
                            <div class="mb-3">
                                <label for="export_code" class="form-label">Mã phiếu:</label>
                                <input type="text" id="export_code" class="form-control" readonly
                                    value="<?php echo e($inventory[0]->inventory_code); ?>">
                            </div>
                            <div class="mb-3">
                                <label for="export_status" class="form-label">Trạng thái:</label>
                                <input type="text" id="export_status" class="form-control" readonly
                                    value="<?php echo e($inventory[0]->inventory_status == 0 ? 'Chưa duyệt' : 'Đã duyệt'); ?>">
                            </div>
                            <div class="mb-3">
                                <label for="participants" class="form-label">Người tham gia:</label>
                                <input type="text" id="participants" class="form-control" readonly
                                    value="<?php echo e($inventory[0]->participants); ?>">
                            </div>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <div class="row">
            <div class="col">
                <div class="card">
                    <div class="card-body">
                        <h5 class="card-title">Chi tiết</h5>
                        <table id="inventory-datatable" class="table dt-responsive nowrap">
                            <thead>
                                <tr>
                                    <th>STT</th>
                                    <th>Vật tư</th>
                                    <th>Nhà sản xuất</th>
                                    <th>Kho</th>
                                    <th>Hao tổn</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $inventory_detail; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <th><?php echo e($key + 1); ?></th>
                                        <th><?php echo e($item->item_name); ?></th>
                                        <th><?php echo e($item->supplier_name); ?></th>
                                        <th><?php echo e($item->warehouse_name); ?></th>
                                        <th style="color: red"><?php echo e($item->item_broken); ?></th>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/js/vendor.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/app.min.js')); ?>"></script>
    <!-- third party js -->
    <script src="<?php echo e(asset('assets/js/vendor/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vendor/dataTables.bootstrap5.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vendor/dataTables.responsive.min.js')); ?>"></script>
    <!-- third party js ends -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.home.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Data\Website\store-app\resources\views/admin/components/inventory/adjust/confirminventory.blade.php ENDPATH**/ ?>