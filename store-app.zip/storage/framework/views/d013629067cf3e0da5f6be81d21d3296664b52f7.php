

<?php $__env->startSection('title'); ?>
    Tồn kho
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <!-- third party css -->
    <link href="<?php echo e(asset('assets/css/vendor/dataTables.bootstrap5.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/css/vendor/responsive.bootstrap5.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/css/vendor/buttons.bootstrap5.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/css/vendor/select.bootstrap5.css')); ?>" rel="stylesheet" type="text/css">
    <!-- third party css end -->

    <link href="<?php echo e(asset('assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/css/app.min.css')); ?>" rel="stylesheet" type="text/css" id="light-style">
    <link href="<?php echo e(asset('assets/css/app-dark.min.css')); ?>" rel="stylesheet" type="text/css" id="dark-style">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Start Content-->
    <div class="container-fluid">
        <!-- start page title -->
        <?php
            $route = preg_replace('/(admin)|\d/i', '', str_replace('/', '', Request::getPathInfo()));
        ?>
        <?php echo e(Breadcrumbs::render($route)); ?>

        <!-- end page title -->
        <?php if(session()->has('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                <?php echo e(session()->get('success')); ?>

            </div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    <?php echo e($error); ?>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <div class="row">
                            <div class="col">
                                <div class="mb-3">
                                    <label for="warehouse" class="form-label">Kho:</label>
                                    <div <?php echo e(count($warehouses) > 1 ? '' : 'hidden'); ?>>
                                        <select data-toggle="select2" title="Warehouse" id="warehouse" name="warehouse">
                                            <?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($warehouse->id); ?>"
                                                    <?php echo e(app('request')->input('warehouse_id') == $warehouse->id ? 'selected' : ''); ?>>
                                                    <?php echo e($warehouse->id); ?> - <?php echo e($warehouse->warehouse_name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                        <br>
                                    </div>
                                    <input type="button" class="btn btn-success" value="Filter" id="btnFilter" hidden>
                                </div>
                            </div>
                            <div class="col">

                            </div>
                        </div>
                        
                            <table id="basic-datatable" class="table dt-responsive nowrap w-100">
                            <thead>
                                <tr>
                                    <th>STT</th>
                                    <th>Tên vật tư</th>
                                    <th>Số lượng</th>
                                    <th>SL khả dụng</th>
                                    <th>SL không khả dụng</th>
                                    <th>Giá kệ</th>
                                    <th>Tầng</th>
                                    <th>Ô</th>
                                    <th>Trạng thái</th>
                                    <th>Ghi chú</th>
                                    <th style="width: 10%">Thao tác</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($key + 1); ?></td>
                                        <td><?php echo e($item->item_name); ?></td>
                                        <td><?php echo e($item->item_detail_quantity); ?></td>
                                        <td><?php echo e($item->item_quantity[0]); ?></td>
                                        <td><?php echo e($item->item_quantity[1]); ?></td>
                                        <td><?php echo e($item->shelf_name); ?></td>
                                        <td><?php echo e($item->floor_id); ?></td>
                                        <td><?php echo e($item->cell_id); ?></td>
                                        <td>
                                            <?php if($item->item_quantity[0] > 0): ?>
                                                <span class="badge bg-success">Còn hàng</span>
                                            <?php else: ?>
                                                <span class="badge bg-danger">hết hàng</span>
                                            <?php endif; ?>
                                        </td>
                                        <td><?php echo e($item->item_note ? $item->item_note : '----- '); ?></td>
                                        <td class="table-action">
                                            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('inv.view')): ?>
                                                <a href="<?php echo e(route('inventory-item.show', $item->itemdetail_id)); ?>" class="action-icon" title="Xem chi tiết">
                                                <i class="mdi mdi-eye-outline"></i></a>
                                            <?php endif; ?>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>

                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/js/vendor.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/app.min.js')); ?>"></script>

    <!-- third party js -->
    <script src="<?php echo e(asset('assets/js/vendor/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vendor/dataTables.bootstrap5.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vendor/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vendor/responsive.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vendor/dataTables.checkboxes.min.js')); ?>"></script>
    <!-- demo js -->
    
    <script src="<?php echo e(asset('assets/js/pages/demo.datatable-init.js')); ?>"></script>
    <script>
        $('document').ready(function() {
            $('#warehouse').on('change', function() {
                document.getElementById("btnFilter").click();
            })
        })
        $('#btnFilter').on('click', function() {
            var warehouse = $('#warehouse').val();
            window.location.href = (warehouse) ? ('?warehouse_id=' + warehouse) : '';
        })
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.home.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEB\store-app\resources\views/admin/components/inventory/inven/inventoryitem.blade.php ENDPATH**/ ?>