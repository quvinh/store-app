<!-- Pre-loader -->
<div id="preloader">
    <div id="status">
        <div class="bouncing-loader">
            <div></div>
            <div></div>
            <div></div>
        </div>
    </div>
</div>
<!-- End Preloader--><?php /**PATH D:\Data\Website\store-app\resources\views/admin/home/preloader.blade.php ENDPATH**/ ?>