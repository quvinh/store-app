<?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('she.add')): ?>
    <div class="row mb-2">
        <div class="col-sm-4">
            <a data-bs-toggle="collapse" href="#collapseExample" aria-expanded="false" aria-controls="collapseExample"
                class="btn btn-danger mb-2 collapsed">
                Tạo mới giá/kệ
            </a>
        </div>
    </div>
    <div class="collapse" id="collapseExample">
        <div class="tab-pane show active" id="custom-styles-preview">
            <?php echo $__env->make('admin.components.shelf.addshelf', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
    </div>
    <div>
        <hr>
    </div>
<?php endif; ?>


<table id="basic-datatable" class="table dt-responsive nowrap w-100">
    <thead>
        <tr>
            <th>STT</th>
            <th>Mã giá/kệ</th>
            <th>Tên giá/kệ</th>
            <th>Vị trí</th>
            <th>Trạng thái</th>
            <th style="width: 10%">Thao tác</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $shelf; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $shelf): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($key + 1); ?></td>
                <td><?php echo e($shelf->shelf_code); ?></td>
                <td><?php echo e($shelf->shelf_name); ?></td>
                <td><?php echo e($shelf->shelf_position); ?></td>
                <td>
                    <?php if($shelf->shelf_status == '1'): ?>
                        <span class="badge bg-success">Active</span>
                    <?php else: ?>
                        <span class="badge bg-danger">Deactive</span>
                    <?php endif; ?>
                </td>
                <td class="table-action">
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('she.edit')): ?>
                        <a href="<?php echo e(route('shelf.edit', $shelf->id)); ?>" class="action-icon">
                            <i class="mdi mdi-square-edit-outline"></i></a>
                    <?php endif; ?>
                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('she.delete')): ?>
                        <a href="<?php echo e(route('shelf.destroy', $shelf->id)); ?>" class="action-icon"><i
                                class="mdi mdi-delete"></i></a>
                    <?php endif; ?>
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH D:\Data\Website\store-app\resources\views/admin/components/shelf/manshelf.blade.php ENDPATH**/ ?>