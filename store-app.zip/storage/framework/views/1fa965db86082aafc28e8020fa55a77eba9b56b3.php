<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8" />
    <title>Log In | 3vsoft</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta content="A fully featured admin theme which can be used to build CRM, CMS, etc." name="description" />
    <meta content="Coderthemes" name="author" />
    <!-- App favicon -->
    <link rel="shortcut icon" href="<?php echo e(asset('images/3v.png')); ?>">

    <!-- App css -->
    <link href="<?php echo e(asset('assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css" />
    <link href="<?php echo e(asset('assets/css/app.min.css')); ?>" rel="stylesheet" type="text/css" id="light-style" />
    <link href="<?php echo e(asset('assets/css/app-dark.min.css')); ?>" rel="stylesheet" type="text/css" id="dark-style" />

</head>

<body class="loading authentication-bg"
    data-layout-config='{"leftSideBarTheme":"dark","layoutBoxed":false, "leftSidebarCondensed":false, "leftSidebarScrollable":false,"darkMode":false, "showRightSidebarOnStart": true}'>
    <?php echo $__env->make('admin.home.preloader', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <div class="account-pages pt-2 pt-sm-5 pb-4 pb-sm-5">
        <div class="container">
            <div class="row justify-content-center">
                <div class="col-xxl-4 col-lg-5">
                    <div class="card">

                        <!-- Logo -->
                        <div class="card-header pt-2 pb-2 text-center bg-primary">
                            <a href="">
                                <span><img src="<?php echo e(asset('images/3v.png')); ?>" alt="LOGO"
                                        height="60"></span>
                            </a>
                        </div>

                        <div class="card-body p-4">
                            <?php if(session()->has('error')): ?>
                                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                                    <button type="button" class="btn-close" data-bs-dismiss="alert"
                                        aria-label="Close"></button>
                                    <?php echo e(session()->get('error')); ?>

                                </div>
                            <?php endif; ?>
                            <?php if(session()->has('success')): ?>
                                <div class="alert alert-success alert-dismissible fade show" role="alert">
                                    <button type="button" class="btn-close" data-bs-dismiss="alert"
                                        aria-label="Close"></button>
                                    <?php echo e(session()->get('success')); ?>

                                </div>
                            <?php endif; ?>
                            <div class="text-center w-75 m-auto">
                                <h4 class="text-dark-50 text-center pb-0 fw-bold"><?php echo app('translator')->get('login.signin'); ?></h4>
                                
                                </p>
                            </div>

                            <form action="<?php echo e(route('login')); ?>" method="POST">
                                <?php echo csrf_field(); ?>
                                <div class="mb-3">
                                    <label for="username" class="form-label"><?php echo app('translator')->get('login.username'); ?></label>
                                    <input class="form-control" type="text" id="username" name="username"
                                        required="" placeholder="<?php echo app('translator')->get('login.enterusername'); ?>" value="<?php echo e(old('username')); ?>">
                                </div>

                                <div class="mb-3">
                                    
                                    <label for="password" class="form-label"><?php echo app('translator')->get('login.password'); ?></label>
                                    <div class="input-group input-group-merge">
                                        <input type="password" id="password" class="form-control" name="password"
                                            placeholder="<?php echo app('translator')->get('login.enterpassword'); ?>" value="<?php echo e(old('password')); ?>">
                                        <div class="input-group-text" data-password="false">
                                            <span class="password-eye"></span>
                                        </div>
                                    </div>
                                </div>

                                <div class="mb-3 mb-3">
                                    <div class="form-check">
                                        <input type="checkbox" class="form-check-input" id="checkbox-signin"
                                            name="remember_me" checked>
                                        <label class="form-check-label" for="checkbox-signin"><?php echo app('translator')->get('login.rememberme'); ?></label>
                                    </div>
                                </div>

                                <div class="mb-3 mb-0 text-center">
                                    <button class="btn btn-primary" type="submit"> <?php echo app('translator')->get('login.login'); ?> </button>
                                </div>

                                <div class="row mb-3">
                                    <div class="col-sm-6 text-center">
                                        <a href="/locale/en"><img src="<?php echo e(asset('assets/images/flags/en.svg')); ?>"
                                                alt="user-image" class="me-1" height="12"> <span
                                                class="align-middle"><?php echo app('translator')->get('login.english'); ?></span></a>
                                    </div>
                                    <div class="col-sm-6 text-center">
                                        <a href="/locale/vn"><img src="<?php echo e(asset('assets/images/flags/vn.svg')); ?>"
                                                alt="user-image" class="me-1" height="12"> <span
                                                class="align-middle"><?php echo app('translator')->get('login.vietnam'); ?></span></a>
                                    </div>
                                </div>

                            </form>
                        </div> <!-- end card-body -->
                    </div>
                    <!-- end card -->

                    <div class="row mt-3">
                        <div class="col-12 text-center">
                            
                            <p class="text-muted"><a href="#"
                                    class="text-muted ms-1"><b><?php echo app('translator')->get('login.forgot'); ?>?</b></a></p>
                        </div> <!-- end col -->
                    </div>
                    <!-- end row -->

                </div> <!-- end col -->
            </div>
            <!-- end row -->
        </div>
        <!-- end container -->
    </div>
    <!-- end page -->

    <footer class="footer footer-alt">
        2022 © 3vsoft.net
    </footer>

    <!-- bundle -->
    <script src="<?php echo e(asset('assets/js/vendor.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/app.min.js')); ?>"></script>

</body>

</html>
<?php /**PATH D:\Data\Website\store-app\resources\views/admin/pages/login.blade.php ENDPATH**/ ?>