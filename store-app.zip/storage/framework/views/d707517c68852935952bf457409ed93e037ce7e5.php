<?php if (! ($breadcrumbs->isEmpty())): ?>
    <div class="row">
        <div class="col-12">
            <div class="page-title-box">
                <div class="page-title-right">
                    <ol class="breadcrumb m-0">
                        <?php $__currentLoopData = $breadcrumbs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $breadcrumb): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php if($breadcrumb->url && !$loop->last): ?>
                                <li class="breadcrumb-item"><a href="<?php echo e($breadcrumb->url); ?>"><?php echo e($breadcrumb->title); ?></a></li>
                            <?php else: ?>
                                <li class="breadcrumb-item"><a href="javascript: void(0);"><?php echo e($breadcrumb->title); ?></a></li>
                            <?php endif; ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </ol>
                </div>
                <h4 class="page-title">
                    <?php
                        $index = count($breadcrumbs) - 1;
                        foreach ($breadcrumbs as $key => $breadcrumbs) {
                            if ($key == $index) {
                                echo $breadcrumb->title;
                            }
                        }
                    ?>
                </h4>
            </div>
        </div>
    </div>
<?php endif; ?>
<?php /**PATH D:\Data\Website\store-app\resources\views/vendor/breadcrumbs/custom.blade.php ENDPATH**/ ?>