<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <table id="export-datatable" class="table table-centered table-striped dt-responsive nowrap w-100">
                    
                    <thead>
                        <tr>
                            <th>Mã phiếu xuất</th>
                            <th>Người tạo</th>
                            <th>Vật tư/ Phụ tùng</th>
                            <th>Trạng thái</th>
                            <th>Thời gian tạo</th>
                            <th style="width: 10%">Thao tác</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $exports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($item->exim_code); ?></td>
                                <td><?php echo e($item->created_by); ?></td>
                                <th>
                                    <?php $__currentLoopData = $item->item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <?php echo e($vt->item); ?><br>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </th>
                                <th>
                                    <?php if($item->exim_status == '0' && $item->deleted_at == null): ?>
                                        Chờ duyệt
                                    <?php elseif($item->exim_status == '1' && $item->deleted_at == null): ?>
                                        Đã duyệt
                                    <?php else: ?>
                                        Đã xóa
                                    <?php endif; ?>
                                </th>
                                <td><?php echo e($item->created_at); ?></td>
                                <td class="table-action">
                                    <a href="<?php echo e(route('export.edit', $item->id)); ?>" class="action-icon">
                                        <i class="mdi mdi-eye-outline"></i></a>
                                    <a href="<?php echo e(route('ex_import.delete', $item->id)); ?>" class="action-icon">
                                        <i class="mdi mdi-delete"></i></a>
                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div> <!-- end card-body-->
        </div> <!-- end card-->
    </div> <!-- end col -->
</div>

<?php /**PATH D:\Data\Website\store-app\resources\views/admin/components/inventory/inven/export.blade.php ENDPATH**/ ?>