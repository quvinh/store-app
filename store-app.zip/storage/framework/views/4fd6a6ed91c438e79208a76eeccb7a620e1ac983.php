<p>Transfer</p>
<?php /**PATH D:\Data\Website\store-app\resources\views/admin/components/inventory/inven/transfer.blade.php ENDPATH**/ ?>