

<?php $__env->startSection('title'); ?>
    Sửa loại vật tư
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <!-- App css -->
    <link href="<?php echo e(asset('assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/css/app.min.css')); ?>" rel="stylesheet" type="text/css" id="light-style">
    <link href="<?php echo e(asset('assets/css/app-dark.min.css')); ?>" rel="stylesheet" type="text/css" id="dark-style">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <!-- start page title -->
        <?php
            $route = preg_replace('/(admin)|\d/i', '', str_replace('/', '', Request::getPathInfo()));
        ?>
        <?php echo e(Breadcrumbs::render($route, $category->id)); ?>

        <!-- end page title -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <div class="tab-content">
                            <form class="needs-validation" novalidate
                                action="<?php echo e(route('category.update',$category->id)); ?>" method="POST"
                                enctype="multipart/form-data">
                                <?php echo csrf_field(); ?>
                                <?php echo method_field('PUT'); ?>
                                <div class="mb-3">
                                    <div class="col s12 m6 l6">
                                        <div class="row mb-2">
                                            <div class="col s6">
                                                <label class="form-label" for="category_code">Mã loại vật tư:</label>
                                                <input type="text" class="form-control" id="category_code" placeholder="Mã loại vật tư"
                                                    required="" name="category_code" value="<?php echo e($category->category_code); ?>">
                                                <div class="invalid-feedback">
                                                    Vui lòng nhập mã loại vật tư.
                                                </div>
                                            </div>
                                            <div class="col s6">
                                                <label class="form-label" for="category_name">Tên loại vật tư:</label>
                                                <input type="text" class="form-control" id="category_name" placeholder="Tên loại vật tư"
                                                    required="" name="category_name" value="<?php echo e($category->category_name); ?>">
                                                <div class="invalid-feedback">
                                                    Vui lòng nhập tên loại vật tư.
                                                </div>
                                            </div>
                                        </div>
                                        <div class="row mb-2">
                                            <div class="col s6">
                                                <label class="form-label" for="category_note">Ghi chú:</label>
                                                <input type="text" class="form-control" id="category_note" placeholder="Ghi chú"
                                                    name="category_note" value="<?php echo e($category->category_note); ?>">
                                            </div>

                                            <div class="col s6">
                                                <span class="form-label" style="font-weight:600">Kích
                                                    hoạt ngay:</span><br><br>
                                                <input type="checkbox" id="switch3" <?php echo e($category->category_status == 1 ? 'checked' : ''); ?> data-switch="success" name="category_status" />
                                                <label for="switch3" data-on-label="Yes" data-off-label="No"></label>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <button class="btn btn-success mb-2 me-1" type="submit">Lưu</button>
                            </form>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/js/vendor.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/app.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.home.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEB\store-app\resources\views/admin/components/category/editcategory.blade.php ENDPATH**/ ?>