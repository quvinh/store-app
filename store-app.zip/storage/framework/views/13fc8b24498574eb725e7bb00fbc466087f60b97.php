

<?php $__env->startSection('title'); ?>
    Thông tin tài khoản
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <!-- App css -->
    <link href="<?php echo e(asset('assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/css/app.min.css')); ?>" rel="stylesheet" type="text/css" id="light-style">
    <link href="<?php echo e(asset('assets/css/app-dark.min.css')); ?>" rel="stylesheet" type="text/css" id="dark-style">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="content-fluid">
        <?php
            $route = preg_replace('/(admin)|\d/i', '', str_replace('/', '', Request::getPathInfo()));
        ?>
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="javascript: void(0);">Hyper</a></li>
                            <li class="breadcrumb-item"><a href="javascript: void(0);">eCommerce</a></li>
                            <li class="breadcrumb-item active">Đơn vị tính</li>
                        </ol>
                    </div>
                    <h4 class="page-title">Thông tin tài khoản</h4>
                </div>
            </div>
        </div>
        <?php if(session()->has('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                <?php echo e(session()->get('success')); ?>

            </div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    <?php echo e($error); ?>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <div class="row">
            <div class="col-xl-4 col-lg-6">
                <div class="card text-center">
                    <div class="card-body">
                        <img src="<?php echo e($profile->image == null ? asset('assets/images/users/avatar.png') : asset($profile->image)); ?>"
                            class="rounded-circle avatar-xl img-thumbnail" alt="profile-image">

                        <h4 class="mb-0 mt-2"><?php echo e($profile->name); ?></h4>

                    </div> <!-- end card-body -->
                </div> <!-- end card -->
            </div>
            <div class="col-xl-8 col-lg-6">
                <div class="card">
                    <div class="card-body">
                        <ul class="nav nav-pills bg-nav-pills nav-justified mb-3">
                            <li class="nav-item">
                                <a href="#aboutme" data-bs-toggle="tab" aria-expanded="true"
                                    class="nav-link rounded-0 active">
                                    <?php echo app('translator')->get('components/profile.myaccount'); ?>
                                </a>
                            </li>

                            <li class="nav-item">
                                <a href="#settings" data-bs-toggle="tab" aria-expanded="false" class="nav-link rounded-0">
                                    <?php echo app('translator')->get('components/profile.changepassword'); ?>
                                </a>
                            </li>
                        </ul>
                        <div class="tab-content">
                            <div class="tab-pane show active" id="aboutme">
                                <form class="" action="<?php echo e(route('account.profile.update', $profile->id)); ?>"
                                    method="POST" enctype="multipart/form-data">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('put'); ?>
                                    
                                    <h5 class="mb-4 text-uppercase"><i class="mdi mdi-account-circle me-1"></i>
                                        <?php echo app('translator')->get('components/profile.accountinfo'); ?></h5>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="name" class="form-label"><?php echo app('translator')->get('components/profile.fullname'); ?></label>
                                                <input type="text" class="form-control" id="name" name="name"
                                                    placeholder="<?php echo app('translator')->get('components/profile.entername'); ?>" required
                                                    value="<?php echo e(old('name') ? old('name') : $profile->name); ?>">
                                            </div>
                                        </div>
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="birthday" class="form-label"><?php echo app('translator')->get('components/profile.birthday'); ?></label>
                                                <input type="date" class="form-control" id="birthday"
                                                    name="birthday" placeholder="<?php echo app('translator')->get('components/profile.enterbirthday'); ?>" required
                                                    value="<?php echo e(old('birthday') ? old('birthday') : $profile->birthday); ?>">
                                            </div>
                                        </div>
                                    </div> <!-- end row -->

                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="username" class="form-label"><?php echo app('translator')->get('components/profile.username'); ?></label>
                                                <input type="text" class="form-control" id="username" name="username"
                                                    placeholder="<?php echo app('translator')->get('components/profile.enterusername'); ?>" required
                                                    value="<?php echo e(old('username') ? old('username') : $profile->username); ?>">
                                            </div>
                                        </div>
                                        <div class="col-6">
                                            <div class="mb-3">
                                                <label for="email" class="form-label"><?php echo app('translator')->get('components/profile.email'); ?></label>
                                                <input type="email" class="form-control" id="email" name="email"
                                                    placeholder="<?php echo app('translator')->get('components/profile.enteremail'); ?>" required
                                                    value="<?php echo e(old('email') ? old('email') : $profile->email); ?>">
                                            </div>
                                        </div> <!-- end col -->
                                    </div> <!-- end row -->
                                    <div class="row">

                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="image" class="form-label"><?php echo app('translator')->get('components/profile.avatar'); ?></label>
                                                <input type="file" class="form-control" name="image" id="image"
                                                    value="<?php echo e(old('image') ? old('image') : $profile->image); ?>">
                                            </div>
                                        </div> <!-- end col -->
                                        <div class="col-md-3">
                                            <label for=""><?php echo app('translator')->get('components/profile.gender'); ?></label>
                                            <div class="mt-1">
                                                <div class="form-check form-check-inline">
                                                    <input type="radio" id="male" name="gender" value="1"
                                                        class="form-check-input"
                                                        <?php echo e($profile->gender == '1' ? 'checked' : ''); ?>>
                                                    <label class="form-check-label"
                                                        for="male"><?php echo app('translator')->get('components/profile.male'); ?></label>
                                                </div>
                                                <div class="form-check form-check-inline">
                                                    <input type="radio" id="female" name="gender" value="0"
                                                        class="form-check-input"
                                                        <?php echo e($profile->gender == '0' ? 'checked' : ''); ?>>
                                                    <label class="form-check-label"
                                                        for="female"><?php echo app('translator')->get('components/profile.female'); ?></label>
                                                </div>
                                            </div>
                                        </div>
                                    </div> <!-- end row -->

                                    <div class="row"></div> <!-- end row -->
                                    <!-- <div class="text-end">
                                        <button type="submit" class="btn btn-success mt-2"><i
                                                class="mdi mdi-content-save"></i> <?php echo app('translator')->get('components/profile.save'); ?></button>
                                    </div> -->
                                </form>

                            </div> <!-- end tab-pane -->
                            <!-- end about me section content -->

                            <div class="tab-pane" id="settings">
                                <form class="" action="<?php echo e(route('account.change-password', $profile->id)); ?>"
                                    method="POST">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('put'); ?>
                                    
                                    <h5 class="mb-4 text-uppercase"><i class="mdi mdi-account-circle me-1"></i>
                                        <?php echo app('translator')->get('components/profile.passwordinfo'); ?></h5>
                                    <div class="row">
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="current-password"
                                                    class="form-label"><?php echo app('translator')->get('components/profile.currentpass'); ?></label>
                                                <input type="password" class="form-control" id="current-password"
                                                    name="current_password" placeholder="<?php echo app('translator')->get('components/profile.enterpass'); ?>"
                                                    value="<?php echo e(old('password') ? old('password') : ''); ?>" required>
                                            </div>
                                        </div> <!-- end col -->
                                        <div class="col-md-6">
                                            <div class="mb-3">
                                                <label for="password" class="form-label"><?php echo app('translator')->get('components/profile.newpass'); ?></label>
                                                <input type="password" class="form-control" id="password"
                                                    name="new_password" placeholder="<?php echo app('translator')->get('components/profile.enterpass'); ?>"
                                                    value="<?php echo e(old('password') ? old('password') : ''); ?>" required>
                                            </div>
                                        </div> <!-- end col -->
                                    </div> <!-- end row -->

                                    <div class="text-end">
                                        <button type="submit" class="btn btn-success mt-2"><i
                                                class="mdi mdi-content-save"></i> <?php echo app('translator')->get('components/profile.save'); ?></button>
                                    </div>
                                </form>
                            </div>
                            <!-- end settings content-->

                        </div> <!-- end tab-content -->
                    </div> <!-- end card body -->
                </div> <!-- end card -->
            </div> <!-- end col -->
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- bundle -->
    <script src="<?php echo e(asset('assets/js/vendor.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/app.min.js')); ?>"></script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.home.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Data\Website\store-app\resources\views/admin/components/account/manprofile.blade.php ENDPATH**/ ?>