
<?php $__env->startSection('title'); ?>
    Bản tin
<?php $__env->stopSection(); ?>
<?php $__env->startSection('css'); ?>
    <!-- App css -->
    <link href="<?php echo e(asset('assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/css/app.min.css')); ?>" rel="stylesheet" type="text/css" id="light-style">
    <link href="<?php echo e(asset('assets/css/app-dark.min.css')); ?>" rel="stylesheet" type="text/css" id="dark-style">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Start Content-->
    <div class="container-fluid">

        <!-- start page title -->
        <?php echo e(Breadcrumbs::render('dashboard')); ?>

        <!-- end page title -->

        <div class="row">
            <div class="col-xl-4 col-lg-4">
                <div class="card cta-box overflow-hidden">
                    <div class="card-body">
                        <h6 for="warehouse" class="text-uppercase mt-0"><a href="#">Kho</a></h6>
                        <?php if(count($warehouses) > 1): ?>
                            <select data-toggle="select2" title="Warehouse" id="warehouse" onchange="filter()">
                                <?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($warehouse->id); ?>"
                                        <?php echo e(app('request')->input('warehouse') == $warehouse->id ? 'selected' : ''); ?>>
                                        <?php echo e($warehouse->warehouse_name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        <?php else: ?>
                            <select data-toggle="select2" title="Warehouse" id="warehouse" disabled>
                                <?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($warehouse->id); ?>"
                                        <?php echo e(app('request')->input('warehouse') == $warehouse->id ? 'selected' : ''); ?>>
                                        <?php echo e($warehouse->warehouse_name); ?>

                                    </option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        <?php endif; ?>

                    </div>
                    <!-- end card-body -->
                </div>
            </div>
            <div class="col-xl-4 col-lg-4">
                <div class="card tilebox-one">
                    <div class="card-body">
                        <a href="#"><i class='uil uil-window-restore float-end'></i></a>
                        <h6 class="text-uppercase mt-0"><a href="#">Vật tư/ phụ tùng đã nhập trong tháng</a></h6>
                        
                        <p class="mb-10 text-muted">
                            <span class="text-success me-2"><span class="mdi mdi-sticker-check"></span>
                                <?php echo e(number_format($sum_im, 0, ',', '.')); ?></span>
                            <span class="text-nowrap"></span>
                        </p>
                    </div> <!-- end card-body-->
                </div>
                <!--end card-->
            </div> <!-- end col -->
            <div class="col-xl-4 col-lg-4">
                <div class="card tilebox-one">
                    <div class="card-body">
                        <a href="#"><i class='uil uil-window-restore float-end'></i></a>
                        <h6 class="text-uppercase mt-0"><a href="#">Vật tư/ phụ tùng đã xuất trong tháng</a></h6>
                        
                        <p class="mb-10 text-muted">
                            <span class="text-success me-2"><span class="mdi mdi-sticker-check"></span>
                                <?php echo e(number_format($sum_ex, 0, ',', '.')); ?></span>
                            <span class="text-nowrap"></span>
                        </p>
                    </div> <!-- end card-body-->
                </div>
                <!--end card-->
            </div> <!-- end col -->
        </div>
        <div class="row">
            <div class="col-6">
                <div class="card">
                    <div class="card-title">
                        <div class="text-center mt-3"><h4>Danh sách nhập chưa duyệt</h4></div>
                    </div>
                    <div class="card-body">
                        <table id="import-datatable" class="table table-centered table-striped dt-responsive nowrap w-100">
                            <thead>
                                <tr>
                                    <th>STT</th>
                                    <th>Mã phiếu nhập</th>
                                    <th>Trạng thái</th>
                                    <th>Thời gian tạo</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $imports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($key+1); ?></td>
                                        <td><a href="<?php echo e(route('import.edit', $item->id)); ?>">
                                                <span class="text-info"><?php echo e($item->exim_code); ?></span></a></td>
                                        <th>
                                            <span style="font-size: 15px" class="badge badge-info-lighten">Chờ duyệt</span>
                                        </th>
                                        <td><?php echo e($item->created); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
            <div class="col-6">
                <div class="card">
                    <div class="card-title">
                        <div class="text-center mt-3"><h4>Danh sách xuất chưa duyệt</h4></div>
                    </div>
                    <div class="card-body">
                        <table id="export-datatable" class="table table-centered table-striped dt-responsive nowrap w-100">
                            <thead>
                                <tr>
                                    <th>STT</th>
                                    <th>Mã phiếu xuất</th>
                                    <th>Trạng thái</th>
                                    <th>Thời gian tạo</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $exports; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($key+1); ?></td>
                                        <td><a href="<?php echo e(route('export.edit', $item->id)); ?>">
                                                <span class="text-info"><?php echo e($item->exim_code); ?></span></a></td>
                                        <th>
                                            <span style="font-size: 15px" class="badge badge-info-lighten">Chờ duyệt</span>
                                        </th>
                                        <td><?php echo e($item->created); ?></td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div>
                </div>
            </div>
        </div>

    </div> <!-- container -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- bundle -->
    <script src="<?php echo e(asset('assets/js/vendor.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/app.min.js')); ?>"></script>

    <!-- third party js -->
    <script src="<?php echo e(asset('assets/js/vendor/Chart.bundle.min.js')); ?>"></script>
    <!-- third party js ends -->

    <!-- demo app -->
    <script src="<?php echo e(asset('assets/js/vendor/apexcharts.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vendor/jquery-jvectormap-1.2.2.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vendor/jquery-jvectormap-world-mill-en.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/pages/demo.dashboard.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            "use strict";
            $("#import-datatable").DataTable({
                language: {
                    paginate: {
                        previous: "<i class='mdi mdi-chevron-left'>",
                        next: "<i class='mdi mdi-chevron-right'>"
                    },
                    info: "Showing import _START_ to _END_ of _TOTAL_",
                    lengthMenu: 'Display <select class="form-select form-select-sm ms-1 me-1"><option value="50">50</option><option value="100">100</option><option value="200">200</option><option value="-1">All</option></select>'
                },
                pageLength: 50,
                columns: [{
                    orderable: !1
                }, {
                    orderable: !1
                }, {
                    orderable: !1
                }, {
                    orderable: !1
                }, ],
                // select: {
                //     style: "multi"
                // },
                // order: true,
                drawCallback: function() {
                    $(".dataTables_paginate > .pagination").addClass("pagination-rounded"), $(
                        "#import-datatable_length label").addClass("form-label")
                },
            })
            $("#export-datatable").DataTable({
                language: {
                    paginate: {
                        previous: "<i class='mdi mdi-chevron-left'>",
                        next: "<i class='mdi mdi-chevron-right'>"
                    },
                    info: "Showing export _START_ to _END_ of _TOTAL_",
                    lengthMenu: 'Display <select class="form-select form-select-sm ms-1 me-1"><option value="50">50</option><option value="100">100</option><option value="200">200</option><option value="-1">All</option></select>'
                },
                pageLength: 50,
                columns: [{
                    orderable: !0
                }, {
                    orderable: !0
                }, {
                    orderable: !0
                }, {
                    orderable: !1
                }, ],
                // select: {
                //     style: "multi"
                // },
                // order: [
                //     [1, "asc"]
                // ],
                drawCallback: function() {
                    $(".dataTables_paginate > .pagination").addClass("pagination-rounded"), $(
                        "#export-datatable_length label").addClass("form-label")
                },
            })
        });
        function filter() {
            // var dt = $('#date_change').val();
            // var dateVal = dt.replace(' - ', '_');
            // dateVal = dateVal.replaceAll('/', '-');
            // var statusVal = $('#status2').val();
            var warehouseVal = $('#warehouse').val();
            const paramsObj = {
                // status: statusVal,
                warehouse: warehouseVal,
                // date: dateVal,
                // type: 0,
            };
            // console.log(statusVal);
            // if (statusVal === '') delete paramsObj.status;
            if (warehouseVal === '') delete paramsObj.warehouse;
            // if (dateVal === '') delete paramsObj.date;
            const searchParams = new URLSearchParams(paramsObj);
            let url = new URL(window.location.href);
            url.search = searchParams;
            window.location.href = url;
        }

    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.home.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEB\store-app\resources\views/admin/home/dashboard.blade.php ENDPATH**/ ?>