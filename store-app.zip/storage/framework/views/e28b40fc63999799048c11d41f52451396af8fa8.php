<table id="scroll-vertical-datatable" class="table dt-responsive nowrap">
    
    <thead>
        <tr>
            <th>STT</th>
            <th>Mã vật tư</th>
            <th>Tên vật tư</th>
            <th>Loại vật tư</th>
            <th>Số lượng</th>
            <th>Đơn vị tính</th>
            <th>Giá nhập</th>
            <th>Giá xuất</th>
            <th>Trọng lượng</th>
            <th>Đơn vị đo trọng lượng</th>
            <th>Chiều dài</th>
            <th>Chiều rộng</th>
            <th>Chiều cao</th>
            <th>SL khả dụng</th>
            <th>SL không khả dụng</th>
            <th>Giá kệ</th>
            <th>Kho</th>
            <th>Trạng thái</th>
            <th>Ghi chú</th>
            <th style="width: 10%">Thao tác</th>
        </tr>
    </thead>
    <tbody>
        <?php $__currentLoopData = $items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($key + 1); ?></td>
                <td><?php echo e($item->item_code); ?></td>
                <td><?php echo e($item->item_name); ?></td>
                <td><?php echo e($item->category_name); ?></td>
                <td><?php echo e($item->item_detail_quantity); ?></td>
                <td><?php echo e($item->unit_name); ?></td>
                <td><?php echo e($item->item_importprice ? $item->item_importprice : '-----'); ?></td>
                <td><?php echo e($item->item_exportprice ? $item->item_exportprice : '-----'); ?></td>
                <td><?php echo e($item->item_weight ? $item->item_weight : '-----'); ?></td>
                <td><?php echo e($item->item_weightuint ? $item->item_weightuint : '-----'); ?></td>
                <td><?php echo e($item->item_long ? $item->item_long : '-----'); ?></td>
                <td><?php echo e($item->item_width ? $item->item_width : '-----'); ?></td>
                <td><?php echo e($item->item_height ? $item->item_height : '-----'); ?></td>
                <td><?php echo e($item->item_valid[0]); ?></td>
                <td><?php echo e($item->item_valid[1]); ?></td>
                <td><?php echo e($item->shelf_name); ?></td>
                <td><?php echo e($item->warehouse_name); ?></td>
                <td>
                    <?php if($item->item_valid[0] > 0): ?>
                        <span class="badge bg-success">Còn hàng</span>
                    <?php else: ?>
                        <span class="badge bg-danger">hết hàng</span>
                    <?php endif; ?>
                </td>
                <td><?php echo e($item->item_note ? $item->item_note : '----- '); ?></td>
                <td class="table-action">
                    x
                </td>
            </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
</table>
<?php /**PATH D:\WEB\store-app\resources\views/admin/components/shelf/shelfdetail.blade.php ENDPATH**/ ?>