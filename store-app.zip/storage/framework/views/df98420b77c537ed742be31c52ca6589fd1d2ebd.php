<!-- ========== Left Sidebar Start ========== -->
<div class="leftside-menu">

    <!-- LOGO -->
    <a href="<?php echo e(route('dashboard.index')); ?>" class="logo text-center logo-light">
        <span class="logo-lg">
            <img src="<?php echo e(asset('images/3v.png')); ?>" alt="" height="64">
        </span>
        <span class="logo-sm">
            <img src="<?php echo e(asset('assets/images/logo_sm.png')); ?>" alt="" height="16">
        </span>
    </a>

    <!-- LOGO -->
    <a href="<?php echo e(route('dashboard.index')); ?>" class="logo text-center logo-dark">
        <span class="logo-lg">
            <img src="<?php echo e(asset('assets/images/logo-dark.png')); ?>" alt="" height="16">
        </span>
        <span class="logo-sm">
            <img src="<?php echo e(asset('assets/images/logo_sm_dark.png')); ?>" alt="" height="16">
        </span>
    </a>

    <div class="h-100" id="leftside-menu-container" data-simplebar="">

        <!--- Sidemenu -->
        <ul class="side-nav">

            <li class="side-nav-title side-nav-item">Apps</li>

            <li class="side-nav-item">
                <a href="<?php echo e(route('dashboard.index')); ?>" class="side-nav-link">
                    <i class="uil-home-alt"></i>
                    <span> Dashboard </span>
                </a>
            </li>
            <li class="side-nav-item">
                <a href="<?php echo e(route('calendar.index')); ?>" class="side-nav-link">
                    <i class="uil-calender"></i>
                    <span> Calendar </span>
                </a>
            </li>
            <li class="side-nav-title side-nav-item">Chức năng</li>



            <li class="side-nav-item">
                <a data-bs-toggle="collapse" href="#sidebarWarehouse" aria-expanded="false"
                    aria-controls="sidebarWarehouse" class="side-nav-link">
                    <i class="uil-store"></i>
                    <span> Kho vật tư </span>
                    <span class="menu-arrow"></span>
                </a>
                <div class="collapse" id="sidebarWarehouse">
                    <ul class="side-nav-second-level">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('war.view')): ?>
                            <li>
                                <a href="<?php echo e(route('warehouse.warehouse-by-id')); ?>">Quản lý kho vật tư</a>
                            </li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('eim.view')): ?>
                            <li>
                                <a href="<?php echo e(route('ex_import.index')); ?>">Quản lý nhập / xuất</a>
                            </li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('tra.view')): ?>
                            <li>
                                <a href="<?php echo e(route('transfer.index')); ?>">Quản lý điều chuyển</a>
                            </li>
                        <?php endif; ?>

                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('inv.view')): ?>
                            <li>
                                <a href="<?php echo e(route('inventory-item.index')); ?>">Quản lý tồn kho</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('inventory.index')); ?>">Quản lý điều chỉnh vật tư</a>
                            </li>
                        <?php endif; ?>

                    </ul>
                </div>
            </li>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sta.view')): ?>
                <li class="side-nav-item">
                    <a data-bs-toggle="collapse" href="#sideStatistic" aria-expanded="false" aria-controls="sideStatistic"
                        class="side-nav-link">
                        <i class="uil-layer-group"></i>
                        <span> Thống kê </span>
                        <span class="menu-arrow"></span>
                    </a>
                    <div class="collapse" id="sideStatistic">
                        <ul class="side-nav-second-level">
                            <li>
                                <a href="<?php echo e(route('statistic.import')); ?>">Thống kê nhập</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('statistic.export')); ?>">Thống kê xuất</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('statistic.transfer')); ?>">Thống kê điều chuyển</a>
                            </li>
                        </ul>
                    </div>
                </li>
            <?php endif; ?>

            <li class="side-nav-item">
                <a data-bs-toggle="collapse" href="#sideGroup" aria-expanded="false" aria-controls="sideGroup"
                    class="side-nav-link">
                    <i class="uil-list-ul"></i>
                    <span> Danh mục </span>
                    <span class="menu-arrow"></span>
                </a>
                <div class="collapse" id="sideGroup">
                    <ul class="side-nav-second-level">
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('ite.view')): ?>
                            <li>
                                <a href="<?php echo e(route('item.index')); ?>">Danh mục vật tư</a>
                            </li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('cat.view')): ?>
                            <li>
                                <a href="<?php echo e(route('category.index')); ?>">Danh mục loại vật tư</a>
                            </li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('uni.view')): ?>
                            <li>
                                <a href="<?php echo e(route('unit.index')); ?>">Danh mục đơn vị tính</a>
                            </li>
                        <?php endif; ?>
                        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sup.view')): ?>
                            <li>
                                <a href="<?php echo e(route('supplier.index')); ?>">Danh mục nhà cung cấp</a>
                            </li>
                        <?php endif; ?>

                    </ul>
                </div>
            </li>
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('sys.view')): ?>
                <li class="side-nav-item">
                    <a data-bs-toggle="collapse" href="#sideSystem" aria-expanded="false" aria-controls="sideSystem"
                        class="side-nav-link">
                        <i class="uil-spin"></i>
                        <span> <?php echo app('translator')->get('leftside.system.system'); ?> </span>
                        <span class="menu-arrow"></span>
                    </a>
                    <div class="collapse" id="sideSystem">
                        <ul class="side-nav-second-level">
                            <li>
                                <a href="<?php echo e(route('account.index')); ?>">Tài khoản</a>
                            </li>
                            <li>
                                <a href="<?php echo e(route('admin.role')); ?>"><?php echo app('translator')->get('leftside.system.role'); ?></a>
                            </li>
                            <li>
                                <a href="<?php echo e(url('/log-viewer')); ?>" target="_blank" rel="noopener noreferrer">Logs</a>
                            </li>
                        </ul>
                    </div>
                </li>
            <?php endif; ?>

        </ul>
        <!-- Help Box -->
        
        <!-- end Help Box -->
        <!-- End Sidebar -->

        <div class="clearfix"></div>

    </div>
    <!-- Sidebar -left -->

</div>
<!-- Left Sidebar End -->
<?php /**PATH D:\WEB\store-app\resources\views/admin/home/leftside.blade.php ENDPATH**/ ?>