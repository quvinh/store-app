<div class="row">
    <div class="col-12">
        <div class="card">
            <div class="card-body">
                <table id="transfer-datatable" class="table table-centered table-striped dt-responsive nowrap w-100">
                    
                    <thead>
                        <tr>
                            <th>STT</th>
                            <th>Mã điều chuyển</th>
                            <th>Người tạo</th>
                            <th>Mô tả</th>
                            <th>Trạng thái</th>
                            <th>Thời gian tạo</th>
                            <th style="width: 10%">Thao tác</th>
                        </tr>
                    </thead>
                    <tbody>
                        <?php $__currentLoopData = $transfers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $transfer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr>
                                <td><?php echo e($key + 1); ?></td>
                                <td><?php echo e($transfer->transfer_code); ?></td>
                                <td><?php echo e($transfer->name); ?></td>
                                <td><?php echo e($transfer->transfer_note); ?></td>
                                <td>
                                    <?php if($transfer->transfer_status == '0' && $transfer->deleted_at == null): ?>
                                        Chờ duyệt
                                    <?php elseif($transfer->transfer_status == '1' && $transfer->deleted_at == null): ?>
                                        Đã duyệt
                                    <?php else: ?>
                                        Đã xóa
                                    <?php endif; ?>
                                </td>
                                <td><?php echo e($transfer->created_at); ?></td>
                                <td class="table-action">
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('tra.edit')): ?>
                                        <a href="<?php echo e(route('transfer.edit', $transfer->id)); ?>" class="action-icon">
                                        <i class="mdi mdi-square-edit-outline" data-bs-toggle="tooltip"
                                            data-bs-placement="top" title="Sửa phiếu"></i></a>
                                    <?php endif; ?>
                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('tra.delete')): ?>
                                        <a href="<?php echo e(route('transfer.delete', $transfer->id)); ?>" class="action-icon">
                                        <i class="mdi mdi-delete" data-bs-toggle="tooltip" data-bs-placement="top"
                                            title="Xóa phiếu"></i></a>
                                    <?php endif; ?>

                                </td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </tbody>
                </table>
            </div> <!-- end card-body-->
        </div> <!-- end card-->
    </div> <!-- end col -->
</div>
<?php /**PATH D:\WEB\store-app\resources\views/admin/components/inventory/inven/transfer.blade.php ENDPATH**/ ?>