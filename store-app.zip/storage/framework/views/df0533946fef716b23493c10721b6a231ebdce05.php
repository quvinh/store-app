

<?php $__env->startSection('title'); ?>
    Quản lý tài khoản
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <!-- third party css -->
    <link href="<?php echo e(asset('assets/css/vendor/dataTables.bootstrap5.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/css/vendor/responsive.bootstrap5.css')); ?>" rel="stylesheet" type="text/css">
    <!-- third party css end -->
    <!-- App css -->
    <link href="<?php echo e(asset('assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/css/app.min.css')); ?>" rel="stylesheet" type="text/css" id="light-style">
    <link href="<?php echo e(asset('assets/css/app-dark.min.css')); ?>" rel="stylesheet" type="text/css" id="dark-style">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
    <div class="container-fluid">
        <!-- start page title -->
        <?php
            $route = preg_replace('/(admin)|\d/i', '', str_replace('/', '', Request::getPathInfo()));
        ?>
        <?php echo e(Breadcrumbs::render($route)); ?>

        <!-- end page title -->
        <?php
            $route = preg_replace('/(admin)|\d/i', '', str_replace('/', '', Request::getPathInfo()));
        ?>
        
        <!-- end page title -->
        <?php if(session()->has('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                <?php echo e(session()->get('success')); ?>

            </div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    <?php echo e($error); ?>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <div class="row mb-2">
                            <div class="col-sm-8">
                                <div class="text-sm-start">
                                    
                                </div>
                            </div>
                            <div class="col-sm-4">
                                <div class="text-sm-end">
                                    
                                </div>
                            </div>
                            <!-- end col-->
                        </div>

                        <div class="table-responsive">
                            <table class="table table-centered table-striped dt-responsive nowrap w-100"
                                id="accounts-datatable">
                                <thead>
                                    <tr>
                                        <th style="width: 20px;" hidden>
                                            <div class="form-check">
                                                <input type="checkbox" class="form-check-input" id="customCheck1">
                                                <label class="form-check-label" for="customCheck1">&nbsp;</label>
                                            </div>
                                        </th>
                                        <th>Customer</th>
                                        <th>Username</th>
                                        <th>Chức vụ</th>
                                        <th>Email</th>
                                        <th>Create Date</th>
                                        <th style="width: 75px;">Action</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $accounts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $account): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td hidden>
                                                <div class="form-check">
                                                    <input type="checkbox" class="form-check-input"
                                                        id="check<?php echo e($key + 1); ?>" value="acc<?php echo e($account->id); ?>">
                                                    <label class="form-check-label"
                                                        for="check<?php echo e($key + 1); ?>">&nbsp;</label>
                                                </div>
                                            </td>
                                            <td class="table-user">
                                                <?php if($account->gender == 1): ?>
                                                    <img src="<?php echo e(asset('images/register/avatarMale.png')); ?>"
                                                        alt="table-user" class="me-2 rounded-circle">
                                                <?php else: ?>
                                                    <img src="<?php echo e(asset('images/register/avatarFemale.png')); ?>"
                                                        alt="table-user" class="me-2 rounded-circle">
                                                <?php endif; ?>
                                                <a href="<?php echo e(route('account.show', $account->id)); ?>"
                                                    class="fw-semibold text-primary"><?php echo e($account->name); ?></a>
                                            </td>
                                            <td>
                                                <span class="text-dark fw-semibold"><?php echo e($account->username); ?></span><br>
                                                <span class="badge badge-success-lighten">Active</span>
                                            </td>
                                            <td>
                                                <?php if($account->getRoleNames()->first() == null): ?>
                                                    <span class="badge badge-outline-warning rounded-pill">Chưa phân
                                                        quyền</span>
                                                <?php else: ?>
                                                    <span
                                                        class="badge badge-outline-primary rounded-pill"><?php echo e($account->getRoleNames()->first()); ?></span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <?php echo e($account->email); ?>

                                            </td>
                                            <td>
                                                <?php echo e($account->created_at); ?>

                                            </td>
                                            <td>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('acc.edit')): ?>
                                                    <a href="<?php echo e(route('account.show', $account->id)); ?>" class="action-icon"> <i
                                                            class="mdi mdi-square-edit-outline"></i></a>
                                                <?php endif; ?>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('acc.delete')): ?>
                                                    <a href="<?php echo e(route('account.destroy', $account->id)); ?>" class="action-icon">
                                                        <i class="mdi mdi-delete"></i></a>
                                                <?php endif; ?>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div>
                    </div> <!-- end card-body-->
                </div> <!-- end card-->
            </div> <!-- end col -->
        </div>
        <!-- end row -->

    </div> <!-- container -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <!-- bundle -->
    <script src="<?php echo e(asset('assets/js/vendor.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/app.min.js')); ?>"></script>
    <!-- third party js -->
    <script src="<?php echo e(asset('assets/js/vendor/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vendor/dataTables.bootstrap5.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vendor/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vendor/responsive.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vendor/dataTables.checkboxes.min.js')); ?>"></script>
    <!-- demo js -->
    <script src="<?php echo e(asset('assets/js/pages/demo.toastr.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/pages/demo.datatable-init.js')); ?>"></script>
    <script>
        $(document).ready(function() {
            "use strict";
            const accounts = <?php echo json_encode($accounts->pluck('id')); ?>;
            console.log(accounts);
            $("#accounts-datatable").DataTable({
                language: {
                    paginate: {
                        previous: "<i class='mdi mdi-chevron-left'>",
                        next: "<i class='mdi mdi-chevron-right'>"
                    },
                    info: "Showing accounts _START_ to _END_ of _TOTAL_",
                    lengthMenu: 'Display <select class="form-select form-select-sm ms-1 me-1"><option value="50">50</option><option value="100">100</option><option value="200">200</option><option value="-1">All</option></select> <a href="<?php echo e(route('account.create')); ?>" class="btn btn-primary btn-sm"><i class="mdi mdi-plus-circle me-2"></i> Add Account</a>'
                },
                pageLength: 50,
                columns: [{
                    orderable: !1
                }, {
                    orderable: !0
                }, {
                    orderable: !0
                }, {
                    orderable: !0
                }, {
                    orderable: !0
                }, {
                    orderable: !0
                }, {
                    orderable: !0
                }],
                select: {
                    style: "multi"
                },
                // order: [
                //     [1, "asc"]
                // ],
                drawCallback: function() {
                    $(".dataTables_paginate > .pagination").addClass("pagination-rounded"), $(
                        "#accounts-datatable_length label").addClass("form-label")
                },
            })
        });

        function notify(title, content, alert) {
            $.NotificationApp.send(title, content, "top-right", "rgba(0,0,0,0.2)", alert);
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.home.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\Data\Website\store-app\resources\views/admin/components/account/manaccount.blade.php ENDPATH**/ ?>