

<?php $__env->startSection('title'); ?>
    Edit Item
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <!-- third party css -->
    <link href="<?php echo e(asset('assets/css/vendor/dataTables.bootstrap5.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/css/vendor/responsive.bootstrap5.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/css/vendor/buttons.bootstrap5.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/css/vendor/select.bootstrap5.css')); ?>" rel="stylesheet" type="text/css">
    <!-- third party css end -->
    <!-- App css -->
    <link href="<?php echo e(asset('assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/css/app.min.css')); ?>" rel="stylesheet" type="text/css" id="light-style">
    <link href="<?php echo e(asset('assets/css/app-dark.min.css')); ?>" rel="stylesheet" type="text/css" id="dark-style">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Start Content-->
    <div class="container-fluid">
        <!-- start page title -->
        <?php
            $route = preg_replace('/(admin)|\d/i', '', str_replace('/', '', Request::getPathInfo()));
        ?>
        <?php echo e(Breadcrumbs::render($route, $item->id)); ?>

        <!-- end page title -->
        <div class="row">
            <div class="col-12">
                <div class="card">

                    <div class="card-body">
                        <div class="row mb-2">
                            <div class="col s2">
                                <a href=<?php echo e(route('item.index')); ?> class="btn btn-info">Quay lại</a>
                            </div>
                        </div><hr>

                        <form class="needs-validation" novalidate action="<?php echo e(route('item.update', $item->id)); ?>"
                            method="POST" enctype="multipart/form-data">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('PUT'); ?>
                            <div class="mb-3">
                                <div class="col s12 m6 l6">
                                    <div class="row mb-2">
                                        <div class="col s6">
                                            <label class="form-label" for="item_code">Mã vật tư:</label>
                                            <input type="text" class="form-control" id="item_code"
                                                placeholder="Mã vật tư" required="" name="item_code"
                                                value=<?php echo e($item->item_code); ?>>
                                            <div class="invalid-feedback">
                                                Vui lòng nhập mã vật tư.
                                            </div>
                                        </div>
                                        <div class="col s6">
                                            <label class="form-label" for="item_name">Tên vật tư:</label>
                                            <input type="text" class="form-control" id="item_name"
                                                placeholder="Tên vật tư" required="" name="item_name"
                                                value=<?php echo e($item->item_name); ?>>
                                            <div class="invalid-feedback">
                                                Vui lòng nhập tên vật tư.
                                            </div>
                                        </div>
                                    </div>
                                    <div class="row mb-2">
                                        <div class="col s6">
                                            <label for="category">Loại vật tư:</label>
                                            <select data-toggle="select2" title="Category" id="category" name="category">
                                                <?php $__currentLoopData = $categories; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($category->id); ?>"
                                                        <?php echo e($category->id == $item->category_id ? 'selected' : ''); ?>>
                                                        <?php echo e($category->category_name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>

                                        <div class="col s6">
                                            <label for="unit">Đơn vị tính:</label>
                                            <select data-toggle="select2" title="Supplier" id="unit" name="item_unit">
                                                <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                    <option value="<?php echo e($unit->id); ?>"
                                                        <?php echo e($unit->id == $item->item_unit ? 'selected' : ''); ?>>
                                                        <?php echo e($unit->unit_name); ?>

                                                    </option>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            </select>
                                        </div>
                                    </div>
                                    <div class="row mb-2">
                                        <div class="col s6">
                                            <label class="form-label" for="item_max">Định mức tối đa:</label>
                                            <input type="text" class="form-control" id="item_max" placeholder="Ghi chú"
                                                name="item_max" value=<?php echo e($item->item_max); ?>>
                                        </div>
                                        <div class="col s6">
                                            <label class="form-label" for="item_min">Định mức tối thiểu:</label>
                                            <input type="text" class="form-control" id="item_min" placeholder="Ghi chú"
                                                name="item_min" value=<?php echo e($item->item_min); ?>>
                                        </div>
                                    </div>
                                    <div class="row mb-2">
                                        <div class="col s6">
                                            <label class="form-label" for="item_note">Ghi chú:</label>
                                            <input type="text" class="form-control" id="item_note"
                                                placeholder="Ghi chú" name="item_note" value=<?php echo e($item->item_note); ?>>
                                        </div>

                                        <div class="col s6">
                                            <span class="form-label" style="font-weight:600">Kích
                                                hoạt ngay:</span><br><br>
                                            <input type="checkbox" id="switch3"
                                                <?php echo e($item->item_status == 1 ? 'checked' : ''); ?> data-switch="success"
                                                name="item_status" />
                                            <label for="switch3" data-on-label="Yes" data-off-label="No"></label>
                                        </div>
                                    </div>

                                    <div class="row mb-2">
                                    </div>
                                </div>
                            </div>
                            <button class="btn btn-success mb-2 me-1" type="submit">Lưu</button>
                        </form>
                    </div>
                </div>
            </div>
        </div>
        <!-- end row -->
    </div> <!-- container -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/js/vendor.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/app.min.js')); ?>"></script>

    <!-- third party js -->
    <script src="<?php echo e(asset('assets/js/vendor/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vendor/dataTables.bootstrap5.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vendor/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vendor/responsive.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vendor/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vendor/buttons.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vendor/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vendor/buttons.flash.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vendor/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vendor/dataTables.keyTable.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vendor/dataTables.select.min.js')); ?>"></script>
    <!-- third party js ends -->

    <!-- demo app -->
    <script src="<?php echo e(asset('assets/js/pages/demo.datatable-init.js')); ?>"></script>
    <!-- end demo js-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.home.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEB\store-app\resources\views/admin/components/item/edititem.blade.php ENDPATH**/ ?>