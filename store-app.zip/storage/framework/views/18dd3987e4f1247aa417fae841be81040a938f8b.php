

<?php $__env->startSection('title'); ?>
    Unit
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <!-- third party css -->
    <link href="<?php echo e(asset('assets/css/vendor/dataTables.bootstrap5.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/css/vendor/responsive.bootstrap5.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/css/vendor/buttons.bootstrap5.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/css/vendor/select.bootstrap5.css')); ?>" rel="stylesheet" type="text/css">
    <!-- third party css end -->
    <!-- App css -->
    <link href="<?php echo e(asset('assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/css/app.min.css')); ?>" rel="stylesheet" type="text/css" id="light-style">
    <link href="<?php echo e(asset('assets/css/app-dark.min.css')); ?>" rel="stylesheet" type="text/css" id="dark-style">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Start Content-->
    <div class="container-fluid">
        <!-- start page title -->
        <div class="row">
            <div class="col-12">
                <div class="page-title-box">
                    <div class="page-title-right">
                        <ol class="breadcrumb m-0">
                            <li class="breadcrumb-item"><a href="javascript: void(0);">Hyper</a></li>
                            <li class="breadcrumb-item"><a href="javascript: void(0);">eCommerce</a></li>
                            <li class="breadcrumb-item active">Danh mục đơn vị tính</li>
                        </ol>
                    </div>
                    <h4 class="page-title">Danh mục đơn vị tính</h4>
                </div>
            </div>
        </div>
        <!-- end page title -->
        <div class="row">
            <div class="col-12">
                <div class="card">
                    <div class="card-body">
                        <div class="row mb-2">
                            <div class="col-sm-4">
                                <a data-bs-toggle="collapse" href="#collapseExample" aria-expanded="false"
                                    aria-controls="collapseExample" class="btn btn-danger mb-2 collapsed">
                                    Tạo mới đơn vị tính
                                </a>
                            </div>
                        </div>
                        <div class="collapse" id="collapseExample">
                            <div class="tab-pane show active" id="custom-styles-preview">
                                <?php echo $__env->make('admin.components.unit.addunit', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
                            </div>
                        </div>
                        <div>
                            <hr>
                        </div>
                        <table id="scroll-vertical-datatable" class="table dt-responsive nowrap">
                            
                            <thead>
                                <tr>
                                    <th>STT</th>
                                    <th>Tên</th>
                                    <th>Số lượng</th>
                                    <th style="width: 10%">Thao tác</th>
                                </tr>
                            </thead>
                            <tbody>
                                <?php $__currentLoopData = $units; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <tr>
                                        <td><?php echo e($key + 1); ?></td>
                                        <td><?php echo e($unit->unit_name); ?></td>
                                        <td><?php echo e($unit->unit_amount); ?></td>
                                        <td class="table-action">
                                            <a href="<?php echo e(route('unit.edit', $unit->id)); ?>" class="action-icon">
                                                <i class="mdi mdi-square-edit-outline"></i></a>
                                            <a href="<?php echo e(route('unit.delete', $unit->id)); ?>" class="action-icon">
                                                <i class="mdi mdi-delete"></i></a>
                                        </td>
                                    </tr>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </tbody>
                        </table>
                    </div> <!-- end card-body-->
                </div> <!-- end card-->
            </div> <!-- end col -->
        </div>
        <!-- end row -->
        <?php if(count($unitTrashed) > 0): ?>
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-title text-center" style="padding-top: 10px">
                            <h4>Danh sách đơn vị tính đã xóa</h4><div align="center"><hr width="95%"></div>
                        </div>
                        <div class="card-body">
                            <table id="scroll-vertical-datatable-trashed" class="table dt-responsive nowrap">
                                
                                <thead>
                                    <tr>
                                        <th>STT</th>
                                        <th>Tên</th>
                                        <th>Số lượng</th>
                                        <th style="width: 10%">Thao tác</th>
                                    </tr>
                                </thead>
                                <tbody>
                                    <?php $__currentLoopData = $unitTrashed; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $unit): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e($key + 1); ?></td>
                                            <td><?php echo e($unit->unit_name); ?></td>
                                            <td><?php echo e($unit->unit_amount); ?></td>
                                            <td class="table-action">
                                                <a href="<?php echo e(route('unit.restore', $unit->id)); ?>" class="action-icon">
                                                    <i class="mdi mdi-delete-restore"></i></a>
                                                <a href="<?php echo e(route('unit.destroy', $unit->id)); ?>" class="action-icon">
                                                    <i class="mdi mdi-delete-forever"></i></a>
                                            </td>
                                        </tr>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </tbody>
                            </table>
                        </div> <!-- end card-body-->
                    </div> <!-- end card-->
                </div> <!-- end col -->
            </div>
        <?php endif; ?>

    </div> <!-- container -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/js/vendor.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/app.min.js')); ?>"></script>
    <!-- third party js -->
    <script src="<?php echo e(asset('assets/js/vendor/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vendor/dataTables.bootstrap5.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vendor/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vendor/responsive.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vendor/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vendor/buttons.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vendor/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vendor/buttons.flash.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vendor/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vendor/dataTables.keyTable.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vendor/dataTables.select.min.js')); ?>"></script>
    <!-- third party js ends -->

    <!-- demo app -->
    <script src="<?php echo e(asset('assets/js/pages/demo.datatable-init.js')); ?>"></script>
    <!-- end demo js-->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.home.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEB\store-app\resources\views/admin/components/unit/manunit.blade.php ENDPATH**/ ?>