

<?php $__env->startSection('title'); ?>
    Ex_Import
<?php $__env->stopSection(); ?>

<?php $__env->startSection('css'); ?>
    <!-- third party css -->
    <link href="<?php echo e(asset('assets/css/vendor/dataTables.bootstrap5.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/css/vendor/responsive.bootstrap5.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/css/vendor/buttons.bootstrap5.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/css/vendor/select.bootstrap5.css')); ?>" rel="stylesheet" type="text/css">
    <!-- third party css end -->
    <!-- App css -->
    <link href="<?php echo e(asset('assets/css/icons.min.css')); ?>" rel="stylesheet" type="text/css">
    <link href="<?php echo e(asset('assets/css/app.min.css')); ?>" rel="stylesheet" type="text/css" id="light-style">
    <link href="<?php echo e(asset('assets/css/app-dark.min.css')); ?>" rel="stylesheet" type="text/css" id="dark-style">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!-- Start Content-->
    <div class="container-fluid">
        <!-- start page title -->
        <?php
            $route = preg_replace('/(admin)|\d/i', '', str_replace('/', '', Request::getPathInfo()));
        ?>
        <?php echo e(Breadcrumbs::render($route)); ?>

        <!-- end page title -->
        <?php if(session()->has('success')): ?>
            <div class="alert alert-success alert-dismissible fade show" role="alert">
                <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                <?php echo e(session()->get('success')); ?>

            </div>
        <?php endif; ?>
        <?php if($errors->any()): ?>
            <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="alert alert-warning alert-dismissible fade show" role="alert">
                    <button type="button" class="btn-close" data-bs-dismiss="alert" aria-label="Close"></button>
                    <?php echo e($error); ?>

                </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
        <!-- start page title -->
        <ul class="nav nav-tabs nav-bordered mb-3">
            <li class="nav-item">
                <a href="#import" data-bs-toggle="tab" aria-expanded="true" class="nav-link active">
                    <i class="mdi mdi-home-variant d-md-none d-block"></i>
                    <span class="d-none d-md-block">Quản lý phiếu nhập</span>
                </a>
            </li>
            <li class="nav-item">
                <a href="#export" data-bs-toggle="tab" aria-expanded="false" class="nav-link">
                    <i class="mdi mdi-account-circle d-md-none d-block"></i>
                    <span class="d-none d-md-block">Quản lý phiếu xuất</span>
                </a>
            </li>
        </ul>

        <div class="tab-content">
            <div class="tab-pane show active" id="import">
                <div class="row">
                    <div class="col-12">

                        <div class="card">
                            <div class="card-body">
                                <div class="row mb-3 mt-3">
                                    <div <?php echo e(count($warehouses) > 1 ? '' : 'hidden'); ?> class="col-3">
                                        <select data-toggle="select2" title="Warehouse" id="warehouse1">
                                            <?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($warehouse->id); ?>"
                                                    <?php echo e(app('request')->input('warehouse') == $warehouse->id ? 'selected' : ''); ?>>
                                                    <?php echo e($warehouse->warehouse_name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-3">
                                        <select data-toggle="select2" title="Status" id="status1">
                                            <option value="">Hiển thị tất cả</option>
                                            <option value="cduyet"
                                                <?php echo e(app('request')->input('status') == 'cduyet' ? 'selected' : ''); ?>>
                                                Hiển thị phiếu chưa duyệt</option>
                                            <option value="duyet"
                                                <?php echo e(app('request')->input('status') == 'duyet' ? 'selected' : ''); ?>>
                                                Hiển thị phiếu đã duyệt</option>
                                        </select>
                                    </div>
                                    <div class="col-sm-3">
                                        <div class="mb-3 input-group">
                                            <span class="input-group-text"><i
                                                    class="mdi mdi-calendar text-primary"></i></span>
                                            <input type="text" class="form-control date" id="date_change1"
                                                data-toggle="date-picker" data-cancel-class="btn-warning"
                                                name="date_change1"
                                                value="<?php echo e(app('request')->input('date') ? str_replace('_', ' - ', str_replace('-', '/', app('request')->input('date'))) : ''); ?>">
                                        </div>
                                    </div>
                                    <div class="col-3 text-end">
                                        <button type="button" class="btn btn-primary" onclick="filter1()">Tìm kiếm</button>
                                    </div>
                                </div>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('eim.add')): ?>
                                    <div class="row mb-2">
                                        <div class="col-sm-4">
                                            <a href="<?php echo e(route('import.index')); ?>" class="btn btn-danger mb-2">
                                                Thêm mới phiếu nhập
                                            </a>
                                        </div>
                                    </div>
                                <?php endif; ?>

                                <hr>
                                <table id="import-datatable"
                                    class="table table-centered table-striped dt-responsive nowrap w-100">
                                    <thead>
                                        <tr>
                                            <th>Mã phiếu nhập</th>
                                            <th>Người tạo</th>
                                            <th>Vật tư/ Phụ tùng</th>
                                            <th>Trạng thái</th>
                                            <th>Thời gian tạo</th>
                                            <th style="width: 10%">Thao tác</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $im_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('eim.edit')): ?>
                                                    <td><a href="<?php echo e(route('import.edit', $item->id)); ?>">
                                                            <span class="text-info"><?php echo e($item->exim_code); ?></span></a></td>
                                                <?php endif; ?>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('eim.edit')): ?>
                                                    <td><span class="text-info"><?php echo e($item->exim_code); ?></span></td>
                                                <?php endif; ?>
                                                <td><?php echo e($item->created_by); ?></td>
                                                <th>
                                                    <?php $__currentLoopData = $item->item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php echo e($vt->item); ?> <br>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </th>
                                                <th>
                                                    <span style="font-size: 15px"
                                                        class="badge badge-<?php echo e($item->exim_status == '0' ? 'info-lighten' : 'success-lighten'); ?>">
                                                        <?php echo e($item->exim_status == '0' ? 'Chờ duyệt' : 'Đã duyệt'); ?></span>
                                                </th>
                                                <td><?php echo e($item->created); ?></td>
                                                <td class="table-action">
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('eim.edit')): ?>
                                                        <a href="<?php echo e(route('import.edit', $item->id)); ?>" class="action-icon">
                                                            <i class="mdi mdi-square-edit-outline" data-bs-toggle="tooltip"
                                                                data-bs-placement="top" title="Sửa phiếu"></i></a>
                                                        <a href="<?php echo e(route('import.confirm', $item->id)); ?>"
                                                            class="action-icon">
                                                            <i class="mdi mdi-clipboard-edit-outline" data-bs-toggle="tooltip"
                                                                data-bs-placement="top" title="Duyệt phiếu"></i></a>
                                                    <?php endif; ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('eim.delete')): ?>
                                                        <a href="<?php echo e(route('ex_import.delete', $item->id)); ?>"
                                                            class="action-icon">
                                                            <i class="mdi mdi-delete" data-bs-toggle="tooltip"
                                                                data-bs-placement="top" title="Xóa phiếu"></i></a>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div> <!-- end card-body-->
                        </div> <!-- end card-->
                    </div> <!-- end col -->
                </div>
            </div>
            <div class="tab-pane" id="export">
                <div class="row">
                    <div class="col-12">
                        <div class="card">
                            <div class="card-body">
                                <div class="row mb-3 mt-3">
                                    <div <?php echo e(count($warehouses) > 1 ? '' : 'hidden'); ?> class="col-3">
                                        <select data-toggle="select2" title="Warehouse" id="warehouse">
                                            <?php $__currentLoopData = $warehouses; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $warehouse): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <option value="<?php echo e($warehouse->id); ?>"
                                                    <?php echo e(app('request')->input('warehouse') == $warehouse->id ? 'selected' : ''); ?>>
                                                    <?php echo e($warehouse->warehouse_name); ?>

                                                </option>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </select>
                                    </div>
                                    <div class="col-3">
                                        <select data-toggle="select2" title="Status" id="status2">
                                            <option value="">Hiển thị tất cả</option>
                                            <option value="cduyet"
                                                <?php echo e(app('request')->input('status') == 'cduyet' ? 'selected' : ''); ?>>
                                                Hiển thị phiếu chưa duyệt</option>
                                            <option value="duyet"
                                                <?php echo e(app('request')->input('status') == 'duyet' ? 'selected' : ''); ?>>
                                                Hiển thị phiếu đã duyệt</option>
                                        </select>
                                    </div>
                                    <div class="col-sm-3">
                                        <div class="mb-3 input-group">
                                            <span class="input-group-text"><i
                                                    class="mdi mdi-calendar text-primary"></i></span>
                                            <input type="text" class="form-control date" id="date_change"
                                                data-toggle="date-picker" data-cancel-class="btn-warning"
                                                name="date_change"
                                                value="<?php echo e(app('request')->input('date') ? str_replace('_', ' - ', str_replace('-', '/', app('request')->input('date'))) : ''); ?>">
                                        </div>
                                    </div>
                                    <div class="col-3 text-end">
                                        <button type="button" class="btn btn-primary" onclick="filter()">Tìm
                                            kiếm</button>
                                    </div>
                                </div>
                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('eim.add')): ?>
                                    <div class="row mb-2">
                                        <div class="col-sm-4">
                                            <a href="<?php echo e(route('export.index')); ?>" class="btn btn-danger mb-2">
                                                Thêm mới phiếu xuất
                                            </a>
                                        </div>
                                    </div>
                                <?php endif; ?>

                                <hr>
                                <table id="export-datatable"
                                    class="table table-centered table-striped dt-responsive nowrap w-100">
                                    
                                    <thead>
                                        <tr>
                                            <th>Mã phiếu xuất</th>
                                            <th>Người tạo</th>
                                            <th>Vật tư/ Phụ tùng</th>
                                            <th>Trạng thái</th>
                                            <th>Thời gian tạo</th>
                                            <th style="width: 10%">Thao tác</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $ex_items; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('eim.edit')): ?>
                                                    <td><a href="<?php echo e(route('export.edit', $item->id)); ?>">
                                                            <span class="text-info"><?php echo e($item->exim_code); ?></span></a></td>
                                                <?php endif; ?>
                                                <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->denies('eim.edit')): ?>
                                                    <td><span class="text-info"><?php echo e($item->exim_code); ?></span></td>
                                                <?php endif; ?>
                                                <td><?php echo e($item->created_by); ?></td>
                                                <th>
                                                    <?php $__currentLoopData = $item->item; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $vt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <?php echo e($vt->item); ?><br>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </th>
                                                <th>
                                                    <span style="font-size: 15px"
                                                        class="badge badge-<?php echo e($item->exim_status == '0' ? 'info-lighten' : 'success-lighten'); ?>">
                                                        <?php echo e($item->exim_status == '0' ? 'Chờ duyệt' : 'Đã duyệt'); ?></span>
                                                </th>
                                                <td><?php echo e($item->created); ?></td>
                                                <td class="table-action">
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('eim.edit')): ?>
                                                        <a href="<?php echo e(route('export.edit', $item->id)); ?>" class="action-icon">
                                                            <i class="mdi mdi-square-edit-outline" data-bs-toggle="tooltip"
                                                                data-bs-placement="top" title="Sửa phiếu"></i></a>
                                                        <a href="<?php echo e(route('export.confirm', $item->id)); ?>"
                                                            class="action-icon">
                                                            <i class="mdi mdi-clipboard-edit-outline" data-bs-toggle="tooltip"
                                                                data-bs-placement="top" title="Duyệt phiếu"></i></a>
                                                    <?php endif; ?>
                                                    <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('eim.delete')): ?>
                                                        <a href="<?php echo e(route('ex_import.delete', $item->id)); ?>"
                                                            class="action-icon"> <i class="mdi mdi-delete"
                                                                data-bs-toggle="tooltip" data-bs-placement="top"
                                                                title="Xóa phiếu"></i></a>
                                                    <?php endif; ?>
                                                </td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div> <!-- end card-body-->
                        </div> <!-- end card-->
                    </div> <!-- end col -->
                </div>
            </div>
        </div>
        <!-- end row -->
    </div> <!-- container -->
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
    <script src="<?php echo e(asset('assets/js/vendor.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/app.min.js')); ?>"></script>

    <!-- third party js -->
    <script src="<?php echo e(asset('assets/js/vendor/jquery.dataTables.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vendor/dataTables.bootstrap5.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vendor/dataTables.responsive.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vendor/responsive.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vendor/dataTables.buttons.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vendor/buttons.bootstrap5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vendor/buttons.html5.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vendor/buttons.flash.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vendor/buttons.print.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vendor/dataTables.keyTable.min.js')); ?>"></script>
    <script src="<?php echo e(asset('assets/js/vendor/dataTables.select.min.js')); ?>"></script>
    <!-- third party js ends -->

    <!-- demo app -->
    <script src="<?php echo e(asset('assets/js/pages/demo.datatable-init.js')); ?>"></script>
    <!-- end demo js-->
    <script>
        $(document).ready(function() {
            "use strict";
            $("#import-datatable").DataTable({
                language: {
                    paginate: {
                        previous: "<i class='mdi mdi-chevron-left'>",
                        next: "<i class='mdi mdi-chevron-right'>"
                    },
                    info: "Showing import _START_ to _END_ of _TOTAL_",
                    lengthMenu: 'Display <select class="form-select form-select-sm ms-1 me-1"><option value="50">50</option><option value="100">100</option><option value="200">200</option><option value="-1">All</option></select>'
                },
                pageLength: 50,
                columns: [{
                    orderable: !1
                }, {
                    orderable: !1
                }, {
                    orderable: !1
                }, {
                    orderable: !1
                }, {
                    orderable: !1
                }, {
                    orderable: !1
                }],
                // select: {
                //     style: "multi"
                // },
                order: true,
                drawCallback: function() {
                    $(".dataTables_paginate > .pagination").addClass("pagination-rounded"), $(
                        "#import-datatable_length label").addClass("form-label")
                },
            })
            $("#export-datatable").DataTable({
                language: {
                    paginate: {
                        previous: "<i class='mdi mdi-chevron-left'>",
                        next: "<i class='mdi mdi-chevron-right'>"
                    },
                    info: "Showing export _START_ to _END_ of _TOTAL_",
                    lengthMenu: 'Display <select class="form-select form-select-sm ms-1 me-1"><option value="50">50</option><option value="100">100</option><option value="200">200</option><option value="-1">All</option></select>'
                },
                pageLength: 50,
                columns: [{
                    orderable: !0
                }, {
                    orderable: !0
                }, {
                    orderable: !0
                }, {
                    orderable: !1
                }, {
                    orderable: !1
                }, {
                    orderable: !1
                }],
                // select: {
                //     style: "multi"
                // },
                // order: [
                //     [1, "asc"]
                // ],
                drawCallback: function() {
                    $(".dataTables_paginate > .pagination").addClass("pagination-rounded"), $(
                        "#export-datatable_length label").addClass("form-label")
                },
            })
        });

        function filter1() {
            var dt = $('#date_change1').val();
            var dateVal = dt.replace(' - ', '_');
            dateVal = dateVal.replaceAll('/', '-');
            var statusVal = $('#status1').val();
            var warehouseVal = $('#warehouse1').val();
            const paramsObj = {
                status: statusVal,
                warehouse: warehouseVal,
                date: dateVal,
                type: 1,
            };
            if (statusVal === '') delete paramsObj.status;
            if (warehouseVal === '') delete paramsObj.warehouse;
            if (dateVal === '') delete paramsObj.date;
            const searchParams = new URLSearchParams(paramsObj);
            let url = new URL(window.location.href);
            url.search = searchParams;
            window.location.href = url;
        }

        function filter() {
            var dt = $('#date_change').val();
            var dateVal = dt.replace(' - ', '_');
            dateVal = dateVal.replaceAll('/', '-');
            var statusVal = $('#status2').val();
            var warehouseVal = $('#warehouse').val();
            const paramsObj = {
                status: statusVal,
                warehouse: warehouseVal,
                date: dateVal,
                type: 0,
            };
            console.log(statusVal);
            if (statusVal === '') delete paramsObj.status;
            if (warehouseVal === '') delete paramsObj.warehouse;
            if (dateVal === '') delete paramsObj.date;
            const searchParams = new URLSearchParams(paramsObj);
            let url = new URL(window.location.href);
            url.search = searchParams;
            window.location.href = url;
        }
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('admin.home.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\WEB\store-app\resources\views/admin/components/ex_import/manex_import.blade.php ENDPATH**/ ?>